import React, { Component } from 'react'
import {Link} from 'react-router-dom'
import {DataContext} from './Context'
import '../Css/Products.css'
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { Grid, Paper, makeStyles } from '@material-ui/core';
import Input from '@material-ui/core/Input';
import Rating from '@material-ui/lab/Rating';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Slider from '@material-ui/core/Slider';
import IconButton from '@material-ui/core/IconButton';
import ShareIcon from '@material-ui/icons/Share';
//import BuyNow from './Compoment/BuyNow';
import SearchIcon from '@material-ui/icons/Search';
import TextField from '@material-ui/core/TextField';
import InputAdornment from '@material-ui/core/InputAdornment';

const theme= {
    root: {
      flexGrow: 1,
      
    },
    paper: {
      // padding: theme.spacing(2),
      //textAlign: "center",
      width:430,
      marginLeft:30,
      // color: theme.palette.text.secondary,
      height:510
    },
    media: {
      height: 140,
    },
    input: {
      width: 42,
    },
    heading: {
      fontSize: 15,
      fontWeight: 20,
    },
    learnbutton: {
      marginLeft:0,
    },
    buybutton:{
      marginTop:0,
    },
    avathar:{
      textAlign:"right",
      backgroundColor:"black",
      width:55,
      height:55
    }
    
  }



export class Products extends Component {
   constructor (){
       super()
       this.state = {
           value:30
        }
       
   }


   handleSliderChange = (event, newValue) => {
       this.setState ({
           value:newValue
       })
    
  };

   handleInputChange = (event) => {
      
           if (event.target.value === '' ){
               this.setState({
                   value:''
               }) 
               }
               else{
                this.setState({
                   value : event.target.value
               })
            }
       
  };

   handleBlur = () => {
    // if (value < 35) {
    //   setValue(35);
    // } else if (value > 1000) {
    //   setValue(1000);
    // }
    this.setState ({
        value:1000
    })
  };

    

    static contextType = DataContext;

    render() {
        const {products,addCart} = this.context;
        return (
          <div style={{"padding":'20px',}}>
          <center>
         
          <TextField
                                id="input-with-icon-textfield"
                                label="Search for Poultry"
                                InputProps={{
                                    startAdornment: (
                                    <InputAdornment position="start">
                                        <IconButton type="submit" aria-label="search">
                                            <SearchIcon />
                                        </IconButton>
                                    </InputAdornment>
                                    ),
                                }}
                                />
          </center>
      
    
         
          <div className="card2">
            <Grid container spacing = {1}> 
             <Grid item xs={2 }>
              
            <Paper style={{backgroundColor:"white",border:"none",borderColor:"white"}}>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={theme.heading}>RATING</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          
          <Rating name="size-medium" defaultValue={5} /><br/>
          
          
          </Typography>
        </AccordionDetails>
      </Accordion>
        
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={theme.heading}>PRICE</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <div style={{width:250}}>
                <Typography>
                <Typography id="input-slider" gutterBottom>
              Volume
            </Typography>
            <Grid container spacing={2} alignItems="center">
              {/* <Grid item>
                <VolumeUp />
              </Grid> */}
              <Grid item xs>
                <Slider
                  //value={typeof this.value === 'number' ? this.value : 0}
                  onChange={this.handleSliderChange}
                  aria-labelledby="input-slider"
                  max="1000"
                />
              </Grid>
              <Grid item>
                <Input
                  style={{width:42}}
                  value={this.state.value}
                  margin="dense"
                  onChange={ this.handleInputChange}
                  onBlur={this.handleBlur}
                  inputProps={{
                    //step: 10,
                    min: 35,
                    max: 1000,
                    type: 'number',
                    'aria-labelledby': 'input-slider',
                  }}
                />
              </Grid>
            </Grid>
      

          </Typography>
          </div>
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={theme.heading}>LAST TIME UPDATED</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            
          <FormControl component="fieldset">
     
     
        <FormControlLabel value="last day" control={<Radio />} label="Last Day" />
        <FormControlLabel value="last week" control={<Radio />} label="Last Week" />
        <FormControlLabel value="last month" control={<Radio />} label="Last Month" />
        <FormControlLabel value="last year" control={<Radio />} label="Last Year" />
        
          </FormControl>
          </Typography>
        </AccordionDetails>
      </Accordion>
        


      </Paper>
    
      </Grid>
      <Grid item xs={10 }>
             
      
            {/* <Grid item xs={8 }>
           <Grid item xs={10 }>
           <Grid item xs={12 }>
          */}
  
            <div id="product" style={{display:"flex"}}>
           
               
               {
                   products.map(product =>(
                      <div className="card" key={product._id}>
                        <div className="card1" key={product._id}>
                        <Grid container spacing = {1}>
                        <Grid item xs={10}>
                          
                         <h3 style={{color:"blue",fontFamily: 'Raleway',fontStyle: 'bold',fontSize:20}}>
                                   <Link to={`/product/${product._id}`}>{product.title}</Link>
                               </h3>
                               </Grid>
                               <Grid item xs={1}/>
                               <Grid item xs={1}>
                               <ShareIcon style={{alignItems:"self-end"}} />
                                 </Grid>
                               </Grid>
                          <p>Available :{product.Avilable}</p>

                     
                           <Link to={`/product/${product._id}`}>
                               <img src={product.src} alt=""/>
                           </Link><br/>
                           <div className="content">
                           <p style={{ textAlign:"center" }}>{product.description}</p>
                           
                           <div style={{display:"flex"}}> 
                           
                          
                           <Grid container spacing = {1}>
                           <Grid item xs={10}>
                               <Rating style={{color:"yellow"}} defaultValue={3} /> <br/> <br/>
                               <Button  href="" color="primary"variant="contained" onClick={()=> addCart(product._id)} style={{backgroundColor:"#0d47a1"}}><strong>
                                      Add to card
                                   </strong></Button>
                                  </Grid>
                                  {/* <Grid item xs={2}/> */}
                                  <Grid item xs={1}>
                                  <span style={{fontFamily: 'Raleway',fontStyle: 'bold',fontSize:24}}>{product.price}.Rs</span><br/><br/>
                                  <Button  href="BuyNow"  color="primary"variant="contained"style={{backgroundColor:"#0d47a1"}} ><strong>
                                 BuyNow
                                </strong></Button>
                                </Grid>
                                </Grid>
                                  <Grid item xs={12}>
                                 
                              
                              
                                
                                  
                        {/* <Button  href="BuyNow" color="primary"variant="contained"style={{color:"black",backgroundColor:"black",marginTop:15,width:145}} ><strong>
                       BuyNow
                      </strong></Button> */}
                      </Grid>
                      </div>
                     
                    
                           </div>
                       </div>
                       </div>
                   ))
               }
            </div>
            </Grid>
            </Grid>  
            {/* </Grid>
            </Grid>  */}
           </div>
           </div>
            
        )
    }
}

export default Products