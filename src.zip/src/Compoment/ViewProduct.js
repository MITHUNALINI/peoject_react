import React from 'react';
import { makeStyles, Checkbox, Table, TableBody, TableCell, TableContainer, TableHead,InputAdornment, TableRow, Paper, Grid,InputBase,TextField} from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import AddBoxIcon from '@material-ui/icons/AddBox';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import { IconButton } from '@material-ui/core';

const useStyles = makeStyles({
  table: {
    minWidth: 900,
  },
  grid: {
      margin: '35px 150px 20px 50px',
      padding: '10px 10px 10px 10px',
      backgroundColor: "black"
  },
  paper: {
    padding: '10px 10px 10px 10px', 
    margin: '10px 10px 10px 10px',
    position: 'inherit'
  },
  search: {
    position: 'relative',
    align:'left',
    },
});





function createData(ShopName, Items, Available , CoverPhotoUrl, Dicribtion,Price) {
  return {ShopName, Items, Available , CoverPhotoUrl, Dicribtion,Price };
}

const rows = [
  createData('aab', 'Hen', '10', 'Src', 'MMMM', '50'),
  createData('aab', 'Duck',  '50', 'Src', 'MMMM' , '50'),
  createData('aab', 'Quails',  '100', 'Src', 'MMMM' , '50'),
  createData('aab', 'Turkey',  '30', 'Src', 'MMMM' , '50'),
  createData('aab', 'Hen',  '25', 'Src', 'MMMM' , '50'),
  createData('aab', 'GuineaFowl',  '20', 'Src', 'MMMM' , '50'),
  createData('aab', 'Duck',  '30', 'Src', 'MMMM' , '50'),
  
  
];

export default function ViewProduct() {
  const classes = useStyles();
  
  
  return (
      <div>
    <Grid className={classes.grid}>
      <Paper className = {classes.paper}>
        <h1>View Product</h1>
        <div className={classes.search}>
            <div className={classes.searchIcon} style = {{float: 'right',marginBottom:"50px"}}>
            
            
            <TextField
        // className={classes.margin}
        id="input-with-icon-textfield"
        label="Search"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon/>
            
            </InputAdornment>
          ),
        }}
      />
              
            </div>
        </div>
        
        <TableContainer>
      <Table className={classes.table} size="small">
        <TableHead>
          <TableRow>
            <TableCell align="left"><b>Action</b></TableCell>
            <TableCell align="left"><b>Shop Name</b></TableCell>
            <TableCell align="left"><b>Items</b></TableCell>
            <TableCell align="left"><b>Available</b></TableCell>
            <TableCell align="left"><b>CoverPhotoUrl</b></TableCell>
            <TableCell align="left"><b>Dicribtion</b></TableCell>
            <TableCell align="left"><b>Price</b></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow>
              
              <TableCell>
              <Checkbox
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'checkbox with default color' }}
              />
              <IconButton>
              <DeleteIcon
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
              />
              </IconButton>

              <IconButton href="/AddUser" >
                <EditIcon 
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
              />
              </IconButton>

              </TableCell>
              <TableCell align="left">{row.ShopName}</TableCell>
              <TableCell align="left">{row.Items}</TableCell>
              <TableCell align="left">{row.Available}</TableCell>
              <TableCell align="left">{row.CoverPhotoUrl}</TableCell>
              <TableCell align="left">{row.Dicribtion}</TableCell>
              <TableCell align="left">{row.Price}</TableCell>
            
            </TableRow>
          ))}
          
        </TableBody>
      </Table>

     
    </TableContainer>

    
    
      </Paper>
    </Grid>
    </div>
  );
}
	
