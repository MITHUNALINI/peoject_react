import React,{Component} from 'react';

import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
// import hen from './Hen.jpeg';
import { Grid, Paper, makeStyles } from '@material-ui/core';


const theme= {
  root: {
    flexGrow: 1,
  },
  paper: {
    // padding: theme.spacing(2),
    textAlign: "center",
    width:400,
    marginLeft:50,
    // color: theme.palette.text.secondary,
  },
  media: {
    height: 140,
  },
}

export default class Test extends Component{
  constructor(){
    super()
  }

  render(){
  return (
    <div style={theme.root}>
      <Paper style={{display:'flex'}}>
      <Paper style={{height:"100vh",width:400,backgroundColor:"red"}}>

      </Paper>
      <Paper elevation={0}>
              {/* <Grid container spacing={3}> */}
              <Paper elevation={0} style={{display:"flex",width:"75vw"}}>
                {/* <Grid item xs={6} sm={3}> */}
                  <Card style={theme.paper }>
                  <CardMedia
                  style={theme.media}
                  // image={hen} style={{height:250,width:400}}
                  />
                
                
                <CardContent>
                  <Typography gutterBottom variant="h5" component="h2">
                    Hen
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p" style={{"fontSize":15}}>
                    A male chicken is called a rooster or a cockerel. A female chicken is called a hen. A young chicken is called a chick. Like other female birds, hens lay eggs. The eggs hatch into chicks. The chickens also need to be protected from predators such as foxes

                  </Typography>
                </CardContent>
            <br></br>
              <CardActions>
            
              {/* <Grid item xs={12}> */}
                <Button href="" size="small" color="primary"variant="contained"><strong>
                  Learn More
                  </strong></Button>
                  {/* </Grid> */}
                <Button  href=""size="small" color="primary"variant="contained"><strong>
                  BuyNow
                  </strong></Button>
              </CardActions>
                  </Card>
                {/* </Grid> */}

                {/* <Grid item xs={6} sm={3}> */}
                  <Card style={theme.paper}>
                  <CardMedia
                  style={theme.media}
                  // image={duck} style={{height:250,width:400}}
                  />
                
                
                <CardContent>
                  <Typography gutterBottom variant="h5" component="h2">
                    Duck
                  </Typography>
                  <Typography variant="body2" color="textSecondary" component="p" style={{"fontSize":15}}>
                  Ducks are birds in the family Anatidae. Ducks are closely related to swans and geese, which are in the same family. Ducks are not a monophyletic group. The main difference is that ducks have shorter necks, and are smaller
                  </Typography>
                </CardContent>
              <br></br>
              <br></br>
              <CardActions>
              {/* <Grid item xs={12}> */}
                <Button href="" size="small" color="primary" variant="contained"><strong>
                  Learn More
                  </strong></Button>
                  {/* </Grid> */}
                <Button  href=""size="small" color="primary"variant="contained"><strong>
                  BuyNow
                  </strong></Button>
              </CardActions>
                  </Card>
                {/* </Grid> */}

                {/* <Grid item xs={6} sm={3}> */}
                  <Card style={theme.paper}>
                  <CardMedia
                  style={theme.media}
                  // image={guineafowl} style={{height:250,width:400}}
                  />
                
                
                <CardContent>
                  <Typography gutterBottom variant="h5" component="h2">
                    Guinea fowl
                  </Typography>
                  <Typography variant="body2" color="textSecondary" component="p" style={{"fontSize":15}}>
                  The Guineafowl are a family of birds. It is in the same order as the pheasants, turkeys and other game birds. Guineafowl are native to the dry arid areas of Africa. They are now bred for meat especially in India
                  
                  </Typography>
                </CardContent>
                <br></br>
              <br></br>
            
              <CardActions>
              {/* <Grid item xs={12}> */}
                <Button href="" size="small" color="primary"variant="contained" style={{marginBottom:0}}><strong>
                  Learn More
                  </strong></Button>
                  {/* </Grid> */}
                <Button  href=""size="small" color="primary"variant="contained"><strong>
                  BuyNow
                  </strong></Button>
              </CardActions>
                  </Card>
                {/* </Grid> */}
                </Paper>
                <br></br>
          <Paper style={{display:"flex"}} elevation={0}>
        {/* <Grid item xs={3}> */}
          <Card style={theme.paper}>
          <CardMedia
          style={theme.media}
          // image={quails} style={{height:250,width:400}}
          />
         
        
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
            Quails
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p" style={{"fontSize":15}}>
          The common quail (Coturnix coturnix), or European quail, is a small ground-nesting game bird in the pheasant family Phasianidae. Coturnix is the Latin for this species. That is a much faster turn around than chickens and ducks, which take almost seven months.
          </Typography>
        </CardContent>
        <br></br>
              <br></br>
      <CardActions>
      {/* <Grid item xs={12}> */}
        <Button href="" size="small" color="primary"variant="contained"><strong>
          Learn More
          </strong></Button>
          {/* </Grid> */}
        <Button  href=""size="small" color="primary"variant="contained"><strong>
          BuyNow
          </strong></Button>
      </CardActions>

          </Card>
          {/* </Grid> */}
        

        {/* <Grid item xs={3}> */}
          <Card style={theme.paper}>
          <CardMedia
          style={theme.media}
          // image={turkey} style={{height:250,width:400}}
          />
         
        
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
            Turkey
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p" style={{"fontSize":15}}>
          Turkeys are a family (Meleagrididae) of bird. They are something like a chicken but much bigger. Wild turkeys live in forests in North America and Central America. In the United States, people traditionally eat turkey on the holiday of Thanksgiving. 
          </Typography>
        </CardContent>
        <br></br>
              <br></br>
              <br></br>
              
      <CardActions>
      {/* <Grid item xs={12} > */}
        <Button href="" size="small" color="primary"variant="contained"><strong>
          Learn More
          </strong></Button>
          {/* </Grid> */}
          {/* <Grid item xs={6} > */}
        <Button  href=""size="small" color="primary"variant="contained"><strong>
          BuyNow
          </strong></Button>
          {/* </Grid> */}
      </CardActions>

          </Card>
          {/* </Grid> */}
          </Paper>
        {/* </Grid> */}
      {/* </Grid> */}
      
      </Paper>
      </Paper>
    </div>
  );
}
}