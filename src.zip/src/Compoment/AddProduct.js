import React, { Component } from "react";
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { Card, CardContent, FormControl, Typography,InputLabel, NativeSelect, FormHelperText } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import AddBoxIcon from '@material-ui/icons/AddBox';
import Button from '@material-ui/core/Button';
import SaveIcon from '@material-ui/icons/Save';
import ReplayIcon from '@material-ui/icons/Replay';

import Select from '@material-ui/core/Select';
import './AddUser.Css';




const style = {
  root: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 50,
    color: '#e0f7fa'
  },
  button: {
    fontSize: '20px'
  },
  formControl: {
   // margin: spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    //marginTop: spacing(2),
  },
}

export default class AddProduct extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Title: "",
      Author: "",
      CoverphotoURL: "",
      ISBNNumber: "",
      Price: "",
      SelectLangue: "",
      SelectGenre: "",
      successful: false
    };
  }

  onChangeTitle = (event) => {
    this.setState({
      Title: event.target.value
    });
  }

  onChangeAuthor = (event) => {
    this.setState({
      Author: event.target.value
    });
  }

  onChangeCoverPhotoURL = (event) => {
    this.setState({
      CoverphotoURL: event.target.value
    });
  }

  onChangeISBNNumber = (event) => {
    this.setState({
      ISBNNumber: event.target.value
    });
  }

  onChangePrice = (event) => {
    this.setState({
      Price: event.target.value
    });
  }

  onChangeSelectLangue = (event) => {
    this.setState({
      SelectLangue: event.target.value
    });
  }

  onChangeSelectGenre = (event) => {
    this.setState({
      SelectGenre: event.target.value
    });
  }

  handleAddBook = (event) => {
    event.preventDefault();

    if (this.state.Title && this.state.Author && this.state.CoverphotoURL && this.state.ISBNNumber && this.state.Price && this.state.SelectLangue && this.state.SelectGenre) {
      console.log(this.state.Title + " " + this.state.Author + " " + this.state.CoverphotoURL + "" +this.state.ISBNNumber + ""+ this.state.Price + "" + this.state.SelectLangue + "" + this.state.SelectGenre)
      this.setState({
        successful: true,
        message: "Success -Book Saved Successfully."
      })
    } else {
      this.setState({
        successful: false,
        message: "Not valied"
      })
    }
  }

  render() {
    return (
      
        <Grid container spacing={1}>
          
        <Grid item xs={4}/>
        <Grid item xs={5} Style={{backgroundColor:"black"}}>
          <Card className={style.root} style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px",marginTop:150}}>
           <CardContent>
           {/* <Paper variant="outlined"> */}
           <div className="card">
             <form className={style.root} noValidate autoComplete="off" style={{width:'150%'}}onSubmit={this.handleRegister}>
                  {!this.state.successful && (
             <Grid container spacing={1}>
                      <Grid item xs={11}>
                        
                      <h3 style={{fontSize:30,color:"#1a237e"}}>Add Products</h3>
                    
                       
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                            
                        <TextField type="text" id="outlined-required" label=" Shop Name" variant="outlined" helperText="Enter your Shop name" style={{width:"120%"}} onChange={this.onChangeTitle} />
                        </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp; 
                        

                        <FormControl variant="outlined" style={style.formControl} Style={{width:"300%"}}>
                        <InputLabel htmlFor="outlined-age-native-simple">ITEMS</InputLabel>
                          <Select
                          native
                          // value={state.age}
                          // onChange={handleChange}
                          label="Age"
                          inputProps={{
                              name: 'age',
                              id: 'outlined-age-native-simple',
          }}
        >
          <option aria-label="None" value="" />
          <option>HEN</option>
          <option >DUCK</option>
          <option>GUINEA FOWL</option>
          <option>QUAILS</option>
          <option>TURKEY</option>
        </Select>
      </FormControl>&emsp; &emsp;  
                        </Grid>
                         
                        <Grid item xs={12}>
                        <FormControl>
                        <TextField type="text" id="outlined-required" label="Available" variant="outlined" helperText="Enter your avaible items" style={{width:"120%"}} onChange={this.onChangeCoverPhotoURL} />
                        </FormControl>&emsp; &emsp; &emsp;  &emsp;  &emsp; 
                        
                      

                      
                        <FormControl>
                        <TextField type="" id="outlined-required" label="cover photo URL" variant="outlined" helperText="Enter poultry cover photo URL"  style={{width:"120%"}}onChange={this.onChangeISBNNumber} />
                        </FormControl>
                        </Grid>

                        <Grid item xs={12}>
                        <FormControl >
                        <TextField type= "" id="outlined-required" label="Dicribtion" variant="outlined" helperText="Enter discribtion " size="small" style={{width:"120%",height:"800"}} onChange={this.onChangePrice}/>
                        </FormControl> &emsp; &emsp; &emsp;  &emsp;  &emsp; 

                        <FormControl >
                        <TextField type= "" id="outlined-required" label="price" variant="outlined" helperText="Enter Poultry  Price " size="small"style={{width:"120%"}} onChange={this.onChangePrice}/>
                        </FormControl>
                        

                        
                        &emsp; &emsp; 
                       </Grid>
                       {/* <Paper variant="outlined">  */}
                        <Grid item xs={12}>
                        <Button href="/Save" variant="contained"onClick={this.handleAddBook} style={{backgroundColor:'#1b5e20',marginLeft:400}}> <SaveIcon style={{fontSize:20}}/>Add</Button>&emsp; 
                        <Button  href="/Reset"variant="contained" style={{backgroundColor:'#0d47a1'}}> <ReplayIcon style={{fontSize:20}}/>RESET</Button>&emsp;
                        {/* <Button href="/upadate" variant="contained" style={{backgroundColor:'#0d47a1'}}><UpdateIcon style={{fontSize:20}}/>Update</Button>  */}
                       {/* </Paper> */}
                        </Grid>
                 </Grid>   
                 )}
                 {this.state.message && (
               <div>
                 <Typography color='#d50000' variant="overline" display="block" gutterBottom> 
                     <strong>{this.state.message}</strong>
                 </Typography>
               </div>
             )}
                
                </form>
                </div>
                {/* </Paper> */}
              </CardContent>
        </Card>
        </Grid>
        <Grid item xs={4}/>
      
      </Grid>
      
    );
                            
}
}